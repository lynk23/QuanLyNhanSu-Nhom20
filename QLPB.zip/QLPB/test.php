<?php
include 'ketnoi.php';
echo "Kết nối thành công tới CSDL QLNS";
?>